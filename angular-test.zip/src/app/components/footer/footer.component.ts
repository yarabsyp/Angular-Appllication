import { Component, Input, OnInit, Output, EventEmitter, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  @Input() onFooterClicked: (args: any) => void;
  @Input() keyword : String;
  @Input() isDisabled: boolean;
  constructor() { 
    this.keyword = "";
    this.isDisabled = false;
    this.onFooterClicked = ()  => {};
  }

  ngOnInit(): void {
  }

  onEditClicked = () => {
    this.isDisabled = false;
  }

  onFooter () {
    this.isDisabled = true;
    this.onFooterClicked(this.keyword)
  }

}
