import { Component, Input, OnInit } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition,
} from '@angular/animations';

@Component({
  selector: 'app-sidebar',
  animations: [
  trigger('submenuShow', [
    // ...
    state('closed', style({
      height: '0'
    })),
    state('open', style({
      height: '*'
    })),
    transition('closed => open', [
      animate('1s')
    ]),
    transition('open => closed', [
      animate('0.5s')
    ]),
  ])
  ],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  @Input() onTabClicked: (val: String, type: Number) => void;
  @Input() selectedList: any;
  @Input() showSubmenu: String;
  constructor() {
    this.onTabClicked = () => {};
    this.selectedList = {}
    this.showSubmenu = "";
  }

  ngOnInit(): void {
  }

  onTabClick = (val: String, type: Number) => {
    this.onTabClicked(val, type);
    return false;
  }

}
