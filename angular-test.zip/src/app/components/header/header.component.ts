import { Component, Input, OnInit, Output, EventEmitter, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Input() onHeaderClicked: (args: any) => void;
  @Input() keyword : String;
  @Input() isDisabled: boolean;
  constructor() { 
    this.keyword = "";
    this.isDisabled = false;
    this.onHeaderClicked = ()  => {};
  }

  ngOnInit(): void {
  }

  onEditClicked = () => {
    this.isDisabled = false;
  }

  onHeader () {
    this.isDisabled = true;
    this.onHeaderClicked(this.keyword)
  }

}
