import { Component, Input, OnInit, Output, EventEmitter, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  @Input() onSearchClicked: (args: any) => void;
  @Input() keyword : String;
  @Input() isDisabled: boolean;
  constructor() { 
    this.keyword = "";
    this.isDisabled = false;
    this.onSearchClicked = ()  => {};
  }

  ngOnInit(): void {
  }

  onEditClicked = () => {
    this.isDisabled = false;
  }

  onSearch () {
    this.isDisabled = true;
    this.onSearchClicked(this.keyword)
  }

}
