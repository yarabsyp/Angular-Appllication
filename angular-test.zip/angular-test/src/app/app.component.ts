import { Component, OnInit } from '@angular/core';
import * as data from 'src/data.json';
import { Router } from '@angular/router';
import {
  trigger,
  state,
  style,
  animate,
  transition,
} from '@angular/animations';

@Component({
  selector: 'app-root',
  animations: [
    trigger('fixedSearch', [
      // ...
      state('fixed', style({
        height: '20vh',
        opacity: 1,
        alignItems: "flex-start",
      })),
      state('not-fixed', style({
        height: '100vh',
        opacity: 0.8,
        alignItems: "center",
      })),
      transition('fixed => not-fixed', [
        animate('1s')
      ]),
      transition('not-fixed => fixed', [
        animate('0.5s')
      ]),
    ]),
    trigger('submenuShow', [
      // ...
      state('closed', style({
        height: '0'
      })),
      state('open', style({
        height: '*'
      })),
      transition('closed => open', [
        animate('1s')
      ]),
      transition('open => closed', [
        animate('0.5s')
      ]),
    ])
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  Dump: any = (data as any).default;
  Data: any;
  Address: any;
  List: any;
  AddressData: any;
  ListTitle: any;
  keyword: any;
  showList: boolean;
  selectedTab: String;
  selectedItem: any;
  showSubmenu: String;
  isDisabled: boolean;
  idx: number;

  constructor(private router: Router,) {
    this.keyword = "";
    this.showList = false;
    this.selectedTab = "";
    this.isDisabled = false;
    this.idx = -1;
    this.showSubmenu = "";
  }

  ngOnInit() {

    // this.List.map((item: any) => {
    //   console.log(item, 'sep obj');

    //   this.ListTitle = item;
    //   // item.items.forEach((data: any) => {
    //   //   // console.log(data, 'data');
    //   //   // if (data.items) {
    //   //   //   data.items.map((item: any) => {
    //   //   this.AddressData = data;
    //   //   console.log(data, 'item array');
    //   //   return data;
    //   //   //   })
    //   //   // }
    //   // })
    //   return item;
    // })

  }

  onSearchClicked () {
    console.log(this.keyword);
    if(this.keyword) {
      this.isDisabled = true;
      this.idx = this.Dump.findIndex((item: any) => item.unique_id === this.keyword);
      if(this.idx > -1) { 
        this.Data = this.Dump[this.idx];
        this.showSubmenu = this.Data.items[0].title;
        this.selectedItem = this.Data.items.length && this.Data.items[0].items.length ? this.Data.items[0].items[0]: {};
        console.log(this.selectedItem);
        this.Address = this.Dump[this.idx].address
        .split(',');
        this.List = this.Dump[this.idx].items;
      } else {
        this.Data = "";
        this.List = "";
        this.Address = "";
      }
      this.showList = true;
      this.isDisabled = true;
    }
  }

  onTitleClick (keyword: String) {
    this.keyword = keyword;
    this.onSearchClicked();
    return false;
  }

  onTabClicked (item: any, type: Number) {
    console.log(item);
    if(type === 0) {
      if(item.hasSubMenu) {
        this.selectedItem = item.items[0];
        this.showSubmenu = item.title;
      } else {
        this.showSubmenu = "";
        this.selectedItem = item;
      }
    } else {
      this.selectedItem = item;
    }
    console.log(this.showSubmenu );
    return false;
  }

  onEditClicked() {
    this.isDisabled = false;
  }

  Submit() {
    this.router.navigate(['/Sidebar']);
  }
}
