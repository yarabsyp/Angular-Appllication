import { Injectable } from '@angular/core';
import {InMemoryDbService} from 'angular-in-memory-web-api'
import * as contents from 'src/data.json';

@Injectable({
  providedIn: 'root'
})
export class DataService implements InMemoryDbService{

  constructor() { }
  createDb(){

   return {contents};

  }

  genId(contents: any): number {
    return contents.length > 0 ? Math.max(...contents.map((content: any) => content.id)) + 1 : 11;
  }
}