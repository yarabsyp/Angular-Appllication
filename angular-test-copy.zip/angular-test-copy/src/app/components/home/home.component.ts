import { Component, OnInit } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition,
} from '@angular/animations';
import { Router } from '@angular/router';
import { ContentService } from '../../services/content.service';

@Component({
  selector: 'app-home',
  animations: [
    trigger('fixedSearch', [
      // ...
      state('fixed', style({
        height: '20vh',
        opacity: 1,
        alignItems: "flex-start",
      })),
      state('not-fixed', style({
        height: '100vh',
        opacity: 0.8,
        alignItems: "center",
      })),
      transition('fixed => not-fixed', [
        animate('1s')
      ]),
      transition('not-fixed => fixed', [
        animate('0.5s')
      ]),
    ])
  ],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  listData: any;
  selectedData: any;
  selectedAddress: any;
  selectedList: any;
  AddressData: any;
  ListTitle: any;
  keyword: String;
  showList: boolean;
  selectedTab: String;
  selectedItem: any;
  showSubmenu: String;
  isDisabled: boolean;
  idx: number;
  contents: any[] = [];
  constructor(private router: Router, private contentService: ContentService) {
    this.keyword = "";
    this.showList = false;
    this.selectedTab = "";
    this.isDisabled = false;
    this.idx = -1;
    this.showSubmenu = "";
  }

  ngOnInit(): void {
    this.contentService.getContents().subscribe((data : any) => {
      console.log(data);
      this.listData = data.default;
    })
  }

  onSearchClicked = (val: String) => {
    this.keyword = val;
    console.log(this.keyword);
    if (this.keyword) {
      this.isDisabled = true;
      this.idx = this.listData.findIndex((item: any) => item.unique_id === this.keyword);
      if (this.idx > -1) {
        this.selectedData = this.listData[this.idx];
        this.showSubmenu = this.selectedData.items[0].title;
        this.selectedItem = this.selectedData.items.length && this.selectedData.items[0].items.length ? this.selectedData.items[0].items[0] : {};
        console.log(this.selectedItem);
        this.selectedAddress = this.listData[this.idx].address
          .split(',');
        this.selectedList = this.listData[this.idx].items;
      } else {
        this.selectedData = "";
        this.selectedList = "";
        this.selectedAddress = "";
      }
      this.showList = true;
      this.isDisabled = true;
    }
  }

  onTitleClicked = (keyword: String) => {
    console.log(keyword);
    this.onSearchClicked(keyword);
    return false;
  }

  onTabClicked = (item: any, type: Number) => {
    console.log(item);
    if (type === 0) {
      if (item.hasSubMenu) {
        this.selectedItem = item.items[0];
        this.showSubmenu = item.title;
      } else {
        this.showSubmenu = "";
        this.selectedItem = item;
      }
    } else {
      this.selectedItem = item;
    }
    console.log(this.showSubmenu);
    return false;
  }

  Submit = () => {
    this.router.navigate(['/Sidebar']);
  }

}
