import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  @Input() listData : Array<any>;
  @Input() onTitleClicked : (args: any) => void;
  @Input() showList : boolean;
  constructor() { 
    this.listData = [];
    this.onTitleClicked = () => {};
    this.showList = false;
  }

  ngOnInit(): void {
  }

  onTitleClick = (val: String) => {
    console.log(val);
    this.onTitleClicked(val);
    return false;
  }

}
