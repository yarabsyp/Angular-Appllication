var Points = /** @class */ (function () {
    function Points() {
    }
    Points.prototype.draw = function () {
        console.log('X: ' + this.x + 'Y: ' + this.y);
    };
    return Points;
}());
var point = new Points;
point.x = 1;
point.y = 3;
point.draw();
